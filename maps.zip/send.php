<?php 

echo $_POST['latitude'];
echo "<br/>";
echo $_POST['longitude'];
